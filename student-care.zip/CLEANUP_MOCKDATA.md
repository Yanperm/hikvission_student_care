# 🗑️ ไฟล์ที่มี Mock Data ที่ต้องแก้ไข

## ✅ แก้ไขแล้ว
- [x] database.py - ลบ default users (เหลือแค่ super admin)
- [x] templates/login.html - ลบ demo credentials

## ⚠️ ยังต้องแก้ไข

### 1. templates/ai_face_recognition.html
- บรรทัด 185: `'รหัส: STD001'` → ใช้ข้อมูลจริง

### 2. templates/all_features.html
- บรรทัด 78: `href="/student/STD001"` → ลบหรือใช้ dynamic

### 3. templates/behavior_score.html
- บรรทัด 104: `<td>STD001</td>` → แสดง "ยังไม่มีข้อมูล"

### 4. templates/learning_analytics.html
- บรรทัด 72: `สมชาย ใจดี (STD001)` → "เลือกนักเรียนจากรายการ"

### 5. templates/mental_health.html
- บรรทัด 88, 96, 97: `STD001` → ใช้ข้อมูลจริง

### 6. templates/multi_user.html
- บรรทัด 102: `admin@school.ac.th` → แสดง "ยังไม่มีข้อมูล"

### 7. templates/parent_dashboard.html & parent_dashboard_new.html
- ตัวอย่าง STD001 → เปลี่ยนเป็นคำอธิบายทั่วไป

### 8. templates/super_admin.html
- บรรทัด 161: `admin@school.com` → `admin@example.com`

### 9. add_parent_relation.py
- บรรทัด 24: ตัวอย่าง STD001 → เป็นแค่ตัวอย่าง (OK)

### 10. firebase_setup.py
- บรรทัด 50-52: Demo data → ลบออก

### 11. local_app.py
- บรรทัด 868: ตัวอย่าง STD001 → เป็นแค่ตัวอย่าง (OK)

### 12. test_database.py
- บรรทัด 25: admin@school.com → ไฟล์ test (OK)

## 📝 หมายเหตุ
- ไฟล์ที่เป็น example/test ไม่ต้องแก้
- ไฟล์ที่แสดงตัวอย่างในคำอธิบาย ไม่ต้องแก้
- แก้เฉพาะไฟล์ที่ใช้งานจริงเท่านั้น

## 🎯 สรุป
**ต้องแก้:** 8 ไฟล์ (templates)
**ไม่ต้องแก้:** 4 ไฟล์ (example/test files)
