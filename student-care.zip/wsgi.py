"""
WSGI Entry Point for Production
© 2025 SOFTUBON CO.,LTD.
"""

from local_app import app

if __name__ == "__main__":
    app.run()
