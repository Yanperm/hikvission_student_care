# ✅ Deploy Checklist

## 🔧 ปัญหาที่ต้องแก้ก่อน Deploy:

### 1. ระบบผู้ปกครอง
- ❌ ไม่มีปุ่ม Logout
- ❌ แสดงข้อมูลแบบ hardcode (STD001)
- ❌ ไม่รองรับหลายบุตร

**แก้ไข:**
- เพิ่มปุ่ม Logout ในทุกหน้า
- ดึงข้อมูลบุตรจาก session/database
- สร้างระบบเชื่อมโยงผู้ปกครอง-นักเรียน

### 2. ระบบ User Management
- ❌ ยังไม่มีตาราง parent_student_relation
- ❌ ผู้ปกครองยังไม่สามารถลงทะเบียนเอง

**แก้ไข:**
- สร้างตาราง parent_student_relation
- เพิ่ม API สำหรับเชื่อมโยงผู้ปกครอง-นักเรียน

### 3. Git Push
- ⚠️ ยังไม่ได้ push code ล่าสุด
- ⚠️ มีการพัฒนาหลายส่วน

**ต้องทำ:**
```bash
git add .
git commit -m "Add LINE OA, Parent Dashboard, Multi-school support"
git push origin main
```

---

## 📝 สิ่งที่ต้องทำก่อน Deploy:

1. ✅ แก้ระบบผู้ปกครอง
2. ✅ เพิ่มปุ่ม Logout
3. ✅ สร้างตาราง parent_student_relation
4. ✅ ทดสอบระบบ
5. ✅ Git push
6. ✅ Deploy to EC2

---

## 🚀 หลัง Deploy ต้องทำ:

1. ตั้งค่า LINE Webhook: `http://43.210.87.220:8080/webhook/line`
2. ทดสอบส่งข้อความไปที่ LINE OA
3. ทดสอบ Login ทุก role
4. ทดสอบกล้องหน้าประตู
5. ทดสอบการแจ้งเตือน

---

ต้องการให้แก้ไขอะไรก่อนครับ?
