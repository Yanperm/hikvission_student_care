# 📦 คู่มือติดตั้ง Student Care System

## ✅ ความต้องการของระบบ

- Windows 10/11, macOS, หรือ Linux
- Python 3.7 ขึ้นไป
- เว็บเบราว์เซอร์ (Chrome, Edge, Firefox, Safari)
- กล้องเว็บแคม (สำหรับเช็คชื่ออัตโนมัติ)

---

## 🚀 วิธีติดตั้ง (ง่ายมาก!)

### ขั้นตอนที่ 1: ติดตั้ง Python

**Windows:**
1. ดาวน์โหลด Python จาก: https://www.python.org/downloads/
2. ติดตั้งและ **เลือก "Add Python to PATH"**
3. ตรวจสอบ: `python --version`

**macOS:**
```bash
brew install python3
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install python3 python3-pip
```

### ขั้นตอนที่ 2: ดาวน์โหลดโปรเจค
```bash
git clone https://github.com/Yanperm/hikvission_student_care.git
cd hikvission_student_care
```

หรือดาวน์โหลด ZIP จาก Github แล้วแตกไฟล์

### ขั้นตอนที่ 3: ติดตั้งระบบ

**Windows:**
- คลิกสองครั้งที่: `install.bat`

**macOS/Linux:**
```bash
chmod +x install.sh
./install.sh
```

ระบบจะติดตั้งอัตโนมัติ รอประมาณ 2-3 นาที

### ขั้นตอนที่ 4: เริ่มใช้งาน

**Windows:**
- คลิกสองครั้งที่: `start.bat`

**macOS/Linux:**
```bash
chmod +x start.sh
./start.sh
```

เปิดเว็บเบราว์เซอร์ไปที่: **http://localhost:5000**

---

## 📱 วิธีใช้งาน

### 1. เพิ่มนักเรียน
- ไปที่หน้าแรก (http://localhost:5000)
- กรอกรหัสนักเรียนและชื่อ
- เปิดกล้อง → ถ่ายรูป → บันทึก

### 2. เช็คชื่ออัตโนมัติ
- ไปที่ "เช็คชื่ออัตโนมัติ" (http://localhost:5000/auto_checkin)
- กล้องจะเปิดอัตโนมัติ
- ระบบจะตรวจจับใบหน้าและเช็คชื่อเอง

### 3. เช็คชื่อด้วยตนเอง
- ไปที่ "เช็คชื่อด้วยตนเอง" (http://localhost:5000/checkin)
- คลิกที่รูปนักเรียนเพื่อเช็คชื่อ

### 4. ดูรายงาน
- ไปที่ "Admin Dashboard" (http://localhost:5000/admin)
- ดูรายชื่อนักเรียนและการเข้าเรียน

---

## 🔧 แก้ปัญหา

### ปัญหา: ติดตั้ง packages ไม่สำเร็จ
```bash
python -m pip install --upgrade pip
pip install Flask opencv-python-headless Pillow requests flask-cors numpy
```

### ปัญหา: กล้องเปิดไม่ได้
- ตรวจสอบว่าเบราว์เซอร์อนุญาตให้ใช้กล้อง
- ลองใช้ Chrome หรือ Edge

### ปัญหา: Port 5000 ถูกใช้งานแล้ว
แก้ไขไฟล์ `local_app.py` บรรทัดสุดท้าย:
```python
app.run(host='0.0.0.0', port=8000, debug=True)  # เปลี่ยนเป็น 8000
```

---

## 📞 ติดต่อสอบถาม

- Github: https://github.com/Yanperm/hikvission_student_care
- Issues: https://github.com/Yanperm/hikvission_student_care/issues

---

## 📄 License

MIT License - ใช้งานได้ฟรี
