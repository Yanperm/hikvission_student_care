# 📦 คู่มือการติดตั้ง Student Care System

## ✅ ความต้องการของระบบ

- Python 3.7 ขึ้นไป
- RAM อย่างน้อย 4GB (แนะนำ 8GB+)
- กล้อง Webcam หรือ Hikvision Camera
- อินเทอร์เน็ต (สำหรับ Cloud Sync)

## 🚀 ขั้นตอนการติดตั้ง

### 1. ติดตั้ง Python Dependencies

```bash
pip install -r requirements.txt
```

### 2. รันระบบ

```bash
python local_app.py
```

### 3. เปิดเว็บเบราว์เซอร์

```
http://localhost:5000
```

## ☁️ การเชื่อมต่อ Cloud

ระบบจะซิงค์ข้อมูลไปยัง AWS Cloud อัตโนมัติ:

- **Cloud URL:** `http://43.210.87.220:8080`
- **ข้อมูลที่ซิงค์:**
  - ข้อมูลนักเรียน
  - การเข้าเรียน
  - พฤติกรรม
  - รายงานต่างๆ

## 📁 โครงสร้างไฟล์

```
Hikvission/
├── local_app.py              # แอปพลิเคชันหลัก
├── local_client.py           # Cloud Sync Client
├── requirements.txt          # Dependencies
├── templates/                # HTML Templates (21 ฟีเจอร์)
├── static/                   # CSS, JS, PWA Files
└── data/
    ├── students/             # รูปภาพนักเรียน
    └── students_data.json    # ข้อมูลนักเรียน (Local)
```

## 🔧 การติดตั้งบนเครื่องอื่น

### Windows:
1. Copy โฟลเดอร์ `Hikvission` ทั้งหมด
2. ติดตั้ง Python 3.7+
3. เปิด Command Prompt ที่โฟลเดอร์
4. รัน: `pip install -r requirements.txt`
5. รัน: `python local_app.py`

### Linux/Mac:
1. Copy โฟลเดอร์ `Hikvission` ทั้งหมด
2. ติดตั้ง Python 3.7+
3. เปิด Terminal ที่โฟลเดอร์
4. รัน: `pip3 install -r requirements.txt`
5. รัน: `python3 local_app.py`

## 🌐 การเข้าถึงจากเครื่องอื่นในเครือข่าย

หากต้องการให้เครื่องอื่นในเครือข่ายเดียวกันเข้าถึงได้:

1. หา IP Address ของเครื่อง Server:
   - Windows: `ipconfig`
   - Linux/Mac: `ifconfig`

2. เครื่องอื่นเปิดเบราว์เซอร์ไปที่:
   ```
   http://[IP-ADDRESS]:5000
   ```
   ตัวอย่าง: `http://192.168.1.100:5000`

## 📱 ติดตั้ง PWA บนมือถือ

1. เปิดเบราว์เซอร์บนมือถือ
2. ไปที่ `http://[IP-ADDRESS]:5000/pwa_mobile`
3. คลิก "เพิ่มไปยังหน้าจอหลัก" หรือ "Install"
4. ใช้งานได้แบบ Native App

## 🔄 Cloud Sync อัตโนมัติ

ระบบจะซิงค์ข้อมูลอัตโนมัติเมื่อ:
- เพิ่มนักเรียนใหม่
- เช็คชื่อ
- บันทึกพฤติกรรม
- มีการเปลี่ยนแปลงข้อมูล

**ไม่ต้องตั้งค่าอะไรเพิ่มเติม!**

## ⚠️ หมายเหตุสำคัญ

1. **ข้อมูล Local:** เก็บที่ `data/students_data.json`
2. **ข้อมูล Cloud:** ซิงค์ไปที่ AWS อัตโนมัติ
3. **รูปภาพ:** เก็บที่ `data/students/` (Local เท่านั้น)
4. **การสำรองข้อมูล:** ควร Backup โฟลเดอร์ `data/` เป็นประจำ

## 🆘 แก้ไขปัญหา

### ไม่สามารถเชื่อมต่อ Cloud
- ตรวจสอบอินเทอร์เน็ต
- ระบบจะทำงานแบบ Offline ได้ปกติ
- ข้อมูลจะซิงค์เมื่อกลับมาออนไลน์

### กล้องไม่ทำงาน
- ตรวจสอบสิทธิ์การเข้าถึงกล้อง
- ลองเปิดเบราว์เซอร์ใหม่
- ใช้ HTTPS หรือ localhost

### Port 5000 ถูกใช้งาน
แก้ไขใน `local_app.py` บรรทัดสุดท้าย:
```python
app.run(host='0.0.0.0', port=5001, debug=True)
```

## 📞 ติดต่อสอบถาม

**SOFTUBON CO.,LTD.**
- Email: support@softubon.com
- Website: www.softubon.com

---

© 2025 SOFTUBON CO.,LTD. (Student Care System.) All rights reserved.
