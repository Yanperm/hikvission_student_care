#!/bin/bash
sudo yum install -y mesa-libGL
