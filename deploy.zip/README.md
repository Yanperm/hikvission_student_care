# Student Care - ระบบเช็คชื่อด้วยใบหน้า

ระบบเช็คชื่อนักเรียนอัตโนมัติด้วยการตรวจจับใบหน้าจากกล้อง Hikvision

## ฟีเจอร์หลัก

- 📹 เชื่อมต่อกล้อง Hikvision ผ่าน RTSP/HTTP API
- 🔍 ตรวจจับและจดจำใบหน้าด้วย OpenCV และ face_recognition
- 📋 ระบบเช็คชื่ออัตโนมัติ
- 👥 จัดการข้อมูลนักเรียน
- 📊 รายงานการเข้าเรียนรายวัน
- 🌐 Web Interface ที่ใช้งานง่าย

## การติดตั้ง

1. ติดตั้ง Python dependencies:
```bash
pip install -r requirements.txt
```

2. รันแอปพลิเคชัน:
```bash
python app.py
```

3. เปิดเว็บเบราว์เซอร์ไปที่: http://localhost:5000

## การใช้งาน

### 1. เชื่อมต่อกล้อง Hikvision
- ใส่ IP Address, Username, Password ของกล้อง
- คลิก "เชื่อมต่อกล้อง"

### 2. เพิ่มนักเรียน
- ใส่รหัสนักเรียน, ชื่อ-นามสกุล, ห้องเรียน
- อัปโหลดรูปภาพใบหน้าที่ชัดเจน
- คลิก "เพิ่มนักเรียน"

### 3. เช็คชื่ออัตโนมัติ
- เมื่อเชื่อมต่อกล้องแล้ว ระบบจะตรวจจับใบหน้าอัตโนมัติ
- เมื่อพบใบหน้าที่จดจำได้ จะบันทึกการเข้าเรียนทันที
- ดูรายการเช็คชื่อได้ในตาราง "การเข้าเรียนวันนี้"

## การตั้งค่ากล้อง Hikvision

1. เปิดใช้งาน RTSP Stream
2. ตั้งค่า User Account ที่มีสิทธิ์ดู Video Stream
3. ตรวจสอบ Network Settings และ Port

### URL ที่ใช้:
- RTSP: `rtsp://username:password@ip:554/Streaming/Channels/101`
- HTTP Snapshot: `http://ip:80/ISAPI/Streaming/channels/101/picture`

## โครงสร้างไฟล์

```
Hikvission/
├── app.py                 # แอปพลิเคชันหลัก
├── requirements.txt       # Dependencies
├── src/
│   ├── hikvision_camera.py      # เชื่อมต่อกล้อง
│   ├── face_recognition_system.py # ระบบจดจำใบหน้า
│   └── attendance_system.py     # ระบบเช็คชื่อ
├── templates/
│   └── index.html        # Web Interface
├── data/
│   ├── students/         # รูปภาพนักเรียน
│   └── attendance.db     # ฐานข้อมูล
└── static/              # ไฟล์ CSS/JS (ถ้ามี)
```

## ข้อกำหนดระบบ

- Python 3.7+
- OpenCV 4.x
- กล้อง Hikvision ที่รองรับ RTSP
- RAM อย่างน้อย 4GB (แนะนำ 8GB+)
- CPU ที่รองรับการประมวลผลภาพ

## การแก้ไขปัญหา

### ไม่สามารถเชื่อมต่อกล้องได้
- ตรวจสอบ IP Address และ Network
- ตรวจสอบ Username/Password
- ตรวจสอบการตั้งค่า Firewall

### ตรวจจับใบหน้าไม่ได้
- ตรวจสอบแสงสว่าง
- ใช้รูปภาพที่ชัดเจนในการลงทะเบียน
- ปรับระยะห่างจากกล้อง

### ประสิทธิภาพช้า
- ลดความละเอียดของกล้อง
- ปรับค่า frame rate
- ใช้ CPU/GPU ที่เร็วกว่า

## License

MIT License