#!/usr/bin/env python3
"""
สคริปต์เพิ่มความสัมพันธ์ระหว่างผู้ปกครอง-นักเรียน
© 2025 SOFTUBON CO.,LTD.
"""

from database import db

def add_relation(parent_username, student_id, relation='parent'):
    """เพิ่มความสัมพันธ์ผู้ปกครอง-นักเรียน"""
    try:
        db.add_parent_student_relation(parent_username, student_id, relation)
        print(f"✅ เพิ่มความสัมพันธ์สำเร็จ: {parent_username} -> {student_id}")
    except Exception as e:
        print(f"❌ เกิดข้อผิดพลาด: {e}")

if __name__ == '__main__':
    print("=" * 60)
    print("🔗 เพิ่มความสัมพันธ์ผู้ปกครอง-นักเรียน")
    print("=" * 60)
    
    # ตัวอย่างการใช้งาน
    print("\n📝 ตัวอย่าง:")
    add_relation('parent@school.com', 'STD001', 'parent')
    
    print("\n" + "=" * 60)
    print("💡 วิธีใช้งาน:")
    print("   python add_parent_relation.py")
    print("   แล้วแก้ไขโค้ดในไฟล์นี้เพื่อเพิ่มความสัมพันธ์")
    print("=" * 60)
